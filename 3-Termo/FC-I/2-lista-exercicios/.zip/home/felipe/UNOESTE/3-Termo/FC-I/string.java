function exibirMensagem()
{
    alert(mensagem)
}
function(gets)
