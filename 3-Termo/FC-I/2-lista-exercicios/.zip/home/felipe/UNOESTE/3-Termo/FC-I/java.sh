FILE_TO_RUN="${1:-'Atualizacao automatica'}"
javac "$FILE_TO_RUN.java" && java "$FILE_TO_RUN"
